type void = Void
type ('a) ucont = U of (('a) dcont -> void)
and ('a) dcont = D of ('a -> ('a) ucont -> void)
and ('a, 'b) pipeline = 'a ucont -> 'b dcont -> void

let get k (U u) (D d) = 
  u (D (fun v u' -> k v u' (D d)))

let put v k (U u) (D d) = 
  d v (U (fun d' -> k () (U u) d'))

let pipe a b u d =
  a u (D (fun v u' -> b (U (fun (D d') -> d' v u')) d))

let run pipeline =
  pipeline (U (fun d' -> Void)) (D (fun v u' -> Void))

let stop (U u) (D d) = Void
